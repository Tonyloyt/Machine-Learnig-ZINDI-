# Zindi_Challenge_Sendy_Logistics
Zindi Challenge 
