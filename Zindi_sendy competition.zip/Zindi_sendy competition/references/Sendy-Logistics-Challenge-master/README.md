# Sendy-Logistics-Challenge
Competition on Zindi
